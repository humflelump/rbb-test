import React from 'react';

export const CurrentKeyContext = React.createContext<any>(void 0);
