import { useActions } from '../src/index';


it('exports useActions', () => {
  expect(typeof useActions).toBe('function');
});