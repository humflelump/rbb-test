import { AtomOrSelector, Listener, Selector } from "../core/types";
import { atom } from "../core/Atom";
import { selector } from "../core/Selector";
import { createId } from "../helpers/createId";

export function createSubscription<ReturnType>(params: {
  id?: string;
  defaultValue: ReturnType;
  inputs?: [];
  onInputsChanged?: (
      current: [],
      prev: [] | null,
      setter: (val: ReturnType) => void
  ) => void;
  onSubscriptionsChanged?: (
      newListeners: Listener[],
      prevListeners: Listener[],
      setter: (val: ReturnType) => void
  ) => void;
  onSubscribe?: (values: [], setter: (val: ReturnType) => void) => void;
  onUnsubscribe?: (values: [], setter: (val: ReturnType) => void) => void;
  }): [Selector<ReturnType>, (val: ReturnType) => void];
  

export function createSubscription<ReturnType, R1>(params: {
  id?: string;
  defaultValue: ReturnType;
  inputs: [AtomOrSelector<R1>];
  onInputsChanged?: (
      current: [R1],
      prev: [R1] | null,
      setter: (val: ReturnType) => void
  ) => void;
  onSubscriptionsChanged?: (
      newListeners: Listener[],
      prevListeners: Listener[],
      setter: (val: ReturnType) => void
  ) => void;
  onSubscribe?: (values: [R1], setter: (val: ReturnType) => void) => void;
  onUnsubscribe?: (values: [R1], setter: (val: ReturnType) => void) => void;
  }): [Selector<ReturnType>, (val: ReturnType) => void];
  

export function createSubscription<ReturnType, R1, R2>(params: {
  id?: string;
  defaultValue: ReturnType;
  inputs: [AtomOrSelector<R1>, AtomOrSelector<R2>];
  onInputsChanged?: (
      current: [R1, R2],
      prev: [R1, R2] | null,
      setter: (val: ReturnType) => void
  ) => void;
  onSubscriptionsChanged?: (
      newListeners: Listener[],
      prevListeners: Listener[],
      setter: (val: ReturnType) => void
  ) => void;
  onSubscribe?: (values: [R1, R2], setter: (val: ReturnType) => void) => void;
  onUnsubscribe?: (values: [R1, R2], setter: (val: ReturnType) => void) => void;
  }): [Selector<ReturnType>, (val: ReturnType) => void];
  

export function createSubscription<ReturnType, R1, R2, R3>(params: {
  id?: string;
  defaultValue: ReturnType;
  inputs: [AtomOrSelector<R1>, AtomOrSelector<R2>, AtomOrSelector<R3>];
  onInputsChanged?: (
      current: [R1, R2, R3],
      prev: [R1, R2, R3] | null,
      setter: (val: ReturnType) => void
  ) => void;
  onSubscriptionsChanged?: (
      newListeners: Listener[],
      prevListeners: Listener[],
      setter: (val: ReturnType) => void
  ) => void;
  onSubscribe?: (values: [R1, R2, R3], setter: (val: ReturnType) => void) => void;
  onUnsubscribe?: (values: [R1, R2, R3], setter: (val: ReturnType) => void) => void;
  }): [Selector<ReturnType>, (val: ReturnType) => void];
  

export function createSubscription<ReturnType, R1, R2, R3, R4>(params: {
  id?: string;
  defaultValue: ReturnType;
  inputs: [AtomOrSelector<R1>, AtomOrSelector<R2>, AtomOrSelector<R3>, AtomOrSelector<R4>];
  onInputsChanged?: (
      current: [R1, R2, R3, R4],
      prev: [R1, R2, R3, R4] | null,
      setter: (val: ReturnType) => void
  ) => void;
  onSubscriptionsChanged?: (
      newListeners: Listener[],
      prevListeners: Listener[],
      setter: (val: ReturnType) => void
  ) => void;
  onSubscribe?: (values: [R1, R2, R3, R4], setter: (val: ReturnType) => void) => void;
  onUnsubscribe?: (values: [R1, R2, R3, R4], setter: (val: ReturnType) => void) => void;
  }): [Selector<ReturnType>, (val: ReturnType) => void];
  

export function createSubscription<ReturnType, R1, R2, R3, R4, R5>(params: {
  id?: string;
  defaultValue: ReturnType;
  inputs: [AtomOrSelector<R1>, AtomOrSelector<R2>, AtomOrSelector<R3>, AtomOrSelector<R4>, AtomOrSelector<R5>];
  onInputsChanged?: (
      current: [R1, R2, R3, R4, R5],
      prev: [R1, R2, R3, R4, R5] | null,
      setter: (val: ReturnType) => void
  ) => void;
  onSubscriptionsChanged?: (
      newListeners: Listener[],
      prevListeners: Listener[],
      setter: (val: ReturnType) => void
  ) => void;
  onSubscribe?: (values: [R1, R2, R3, R4, R5], setter: (val: ReturnType) => void) => void;
  onUnsubscribe?: (values: [R1, R2, R3, R4, R5], setter: (val: ReturnType) => void) => void;
  }): [Selector<ReturnType>, (val: ReturnType) => void];
  

export function createSubscription<ReturnType, R1, R2, R3, R4, R5, R6>(params: {
  id?: string;
  defaultValue: ReturnType;
  inputs: [AtomOrSelector<R1>, AtomOrSelector<R2>, AtomOrSelector<R3>, AtomOrSelector<R4>, AtomOrSelector<R5>, AtomOrSelector<R6>];
  onInputsChanged?: (
      current: [R1, R2, R3, R4, R5, R6],
      prev: [R1, R2, R3, R4, R5, R6] | null,
      setter: (val: ReturnType) => void
  ) => void;
  onSubscriptionsChanged?: (
      newListeners: Listener[],
      prevListeners: Listener[],
      setter: (val: ReturnType) => void
  ) => void;
  onSubscribe?: (values: [R1, R2, R3, R4, R5, R6], setter: (val: ReturnType) => void) => void;
  onUnsubscribe?: (values: [R1, R2, R3, R4, R5, R6], setter: (val: ReturnType) => void) => void;
  }): [Selector<ReturnType>, (val: ReturnType) => void];

export function createSubscription(params) {
  const {
    defaultValue,
    onInputsChanged,
    onSubscriptionsChanged,
    onSubscribe,
    onUnsubscribe
  } = params;
  const id = params.id || '-';
  const inputs = params.inputs || [];
  const uid = createId();

  const [subAtom, inputsCacheAtom] = [defaultValue, null].map((data, i) => {
    return atom({
      id: `${i}_${id}`,
      data,
      metadata: { subscription: uid, id },
    });
  })

  const setter = val => subAtom.set(val);

  const subSelector = selector({
    id: `s_${id}`,
    inputs,
    func: (...vals) => {
      const outputs = vals.slice(0, vals.length - 1);
      const key = vals[vals.length - 1];
      const prevOutputs = inputsCacheAtom.get(key);
      inputsCacheAtom.set(outputs, key);
      if (onInputsChanged) {
        onInputsChanged(outputs, prevOutputs, setter);
      }
    },
    listenersChanged: (cur, prev, key) => {
      onSubscriptionsChanged && onSubscriptionsChanged(cur, prev, setter);
      if (cur.length > 0 && prev.length === 0) {
        const vals = inputs.map(d => d.get(key));
        onSubscribe && onSubscribe(vals, setter);
      }
      if (cur.length === 0 && prev.length > 0) {
        const vals = inputs.map(d => d.get(key));
        onUnsubscribe && onUnsubscribe(vals, setter);
      }
    }
  });

  const resultSelector = selector({
    id: `subscription_${id}`,
    inputs: [subSelector, subAtom],
    func: (a, b) => b,
  })

  return [resultSelector, setter];
}
