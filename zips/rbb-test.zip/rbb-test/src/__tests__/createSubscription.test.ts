import { atom, createSubscription } from ".."

const MS = 5;

const timeout = (f, ms, done) => {
  setTimeout(() => {
    try {
      f();
    } catch (e) {
      done(e);
    }
  }, ms);
};

it('is exported', () => {
    expect(typeof createSubscription).toBe('function');
});

it('has core functionality', (done) => {
    const a = atom(5);

    let counterAtom = atom(0);
    let interval;

    let [c1, c2, c3, c4] = [null, null, null, null];

    const [sub, setter] = createSubscription({
        id: 'sub',
        defaultValue: 0,
        inputs: [a],
        onInputsChanged: (curr, prev, setter) => {
            c1 = [curr, prev, setter];
        },
        onSubscriptionsChanged: (curr, prev, setter) => {
            c2 = [curr, prev, setter];
        },
        onSubscribe: (vals, setter) => {
            c3 = [vals, setter];
            interval = setInterval(() => {
                counterAtom.update(n => n + 1);
            }, 5 * MS);
        },
        onUnsubscribe: (vals, setter) => {
            c4 = [vals, setter];
            clearInterval(interval);
        },
    });
    expect(c1).toEqual(null);
    expect(c2).toEqual(null);
    expect(c3).toEqual(null);
    expect(c4).toEqual(null);

    let calls = 0;
    const subscription = () => {
        calls++;
    }
    sub.subscribe(subscription);
    expect(c1).toEqual(null);
    expect(c2).toEqual([[subscription], [], setter]);
    expect(c3).toEqual([[5], setter]);
    expect(c4).toEqual(null);

    a.set(6);
    expect(sub.get()).toBe(0);
    expect(calls).toBe(1);
    expect(c1).toEqual([[6], null, setter]);

    timeout(() => {
        sub.unsubscribe(subscription);
        expect(c1).toEqual([[6], null, setter]);
        expect(c2).toEqual([[], [subscription], setter]);
        expect(c3).toEqual([[5], setter]);
        expect(c4).toEqual([[6], setter]);
        //console.log('got', counterAtom.get());
        expect(counterAtom.get()).toBe(2);
        timeout(() => {
            expect(counterAtom.get()).toBe(2);
            done();
        }, 12.5 * MS, done);
        done()
    }, 12.5 * MS, done);


})

