import { IStore } from 'redab-core';
import { Atom, AtomOrSelector, Selector } from 'redab-core';
import { AnyFunction, AsyncActionState } from './types';
import { Action } from '.';
export declare function createAsyncAction<Use extends {
    [key: string]: AtomOrSelector<any> | Action<AnyFunction>;
}, Func extends (...p: any[]) => Promise<any>>(props: {
    id?: string;
    use: Use;
    func: (node: Use, status: AsyncActionState) => Func;
    multi?: boolean;
    key?: any;
    loggingMap?: Map<Atom<any>, any>;
    store?: IStore;
}): [Action<Func>, Selector<boolean>, Selector<Error | undefined>];
