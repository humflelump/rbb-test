import { AtomOrSelector, Selector } from 'redab-core';
import { AsyncSelectorPromiseState } from './types';
import { Action } from '.';
export declare function createAsyncSelector<ReturnType, DefaultValue = null>(params: {
    defaultValue: DefaultValue;
    inputs?: [];
    func: (state: AsyncSelectorPromiseState<ReturnType>) => Promise<ReturnType>;
    id?: string;
    shouldUseAsync?: () => boolean;
    throttle?: (f: () => void) => () => void;
    onResolve?: (result: ReturnType) => void;
    onReject?: (err: Error) => void;
}): [
    Selector<ReturnType | DefaultValue>,
    Selector<boolean>,
    Selector<any | undefined>,
    Action<() => Promise<ReturnType>>
];
export declare function createAsyncSelector<S1, ReturnType, DefaultValue = null>(params: {
    defaultValue: DefaultValue;
    inputs: [AtomOrSelector<S1>];
    func: (val1: S1, state: AsyncSelectorPromiseState<ReturnType>) => Promise<ReturnType>;
    id?: string;
    shouldUseAsync?: (val1: S1) => boolean;
    throttle?: (f: () => void) => () => void;
    onResolve?: (result: ReturnType) => void;
    onReject?: (err: Error) => void;
}): [
    Selector<ReturnType | DefaultValue>,
    Selector<boolean>,
    Selector<any | undefined>,
    Action<() => Promise<ReturnType>>
];
export declare function createAsyncSelector<S1, S2, ReturnType, DefaultValue = null>(params: {
    defaultValue: DefaultValue;
    inputs: [AtomOrSelector<S1>, AtomOrSelector<S2>];
    func: (val1: S1, val2: S2, state: AsyncSelectorPromiseState<ReturnType>) => Promise<ReturnType>;
    id?: string;
    shouldUseAsync?: (val1: S1, val2: S2) => boolean;
    throttle?: (f: () => void) => () => void;
    onResolve?: (result: ReturnType) => void;
    onReject?: (err: Error) => void;
}): [
    Selector<ReturnType | DefaultValue>,
    Selector<boolean>,
    Selector<any | undefined>,
    Action<() => Promise<ReturnType>>
];
export declare function createAsyncSelector<S1, S2, S3, ReturnType, DefaultValue = null>(params: {
    defaultValue: DefaultValue;
    inputs: [AtomOrSelector<S1>, AtomOrSelector<S2>, AtomOrSelector<S3>];
    func: (val1: S1, val2: S2, val3: S3, state: AsyncSelectorPromiseState<ReturnType>) => Promise<ReturnType>;
    id?: string;
    shouldUseAsync?: (val1: S1, val2: S2, val3: S3) => boolean;
    throttle?: (f: () => void) => () => void;
    onResolve?: (result: ReturnType) => void;
    onReject?: (err: Error) => void;
}): [
    Selector<ReturnType | DefaultValue>,
    Selector<boolean>,
    Selector<any | undefined>,
    Action<() => Promise<ReturnType>>
];
export declare function createAsyncSelector<S1, S2, S3, S4, ReturnType, DefaultValue = null>(params: {
    defaultValue: DefaultValue;
    inputs: [
        AtomOrSelector<S1>,
        AtomOrSelector<S2>,
        AtomOrSelector<S3>,
        AtomOrSelector<S4>
    ];
    func: (val1: S1, val2: S2, val3: S3, val4: S4, state: AsyncSelectorPromiseState<ReturnType>) => Promise<ReturnType>;
    id?: string;
    shouldUseAsync?: (val1: S1, val2: S2, val3: S3, val4: S4) => boolean;
    throttle?: (f: () => void) => () => void;
    onResolve?: (result: ReturnType) => void;
    onReject?: (err: Error) => void;
}): [
    Selector<ReturnType | DefaultValue>,
    Selector<boolean>,
    Selector<any | undefined>,
    Action<() => Promise<ReturnType>>
];
export declare function createAsyncSelector<S1, S2, S3, S4, S5, ReturnType, DefaultValue = null>(params: {
    defaultValue: DefaultValue;
    inputs: [
        AtomOrSelector<S1>,
        AtomOrSelector<S2>,
        AtomOrSelector<S3>,
        AtomOrSelector<S4>,
        AtomOrSelector<S5>
    ];
    func: (val1: S1, val2: S2, val3: S3, val4: S4, val5: S5, state: AsyncSelectorPromiseState<ReturnType>) => Promise<ReturnType>;
    id?: string;
    shouldUseAsync?: (val1: S1, val2: S2, val3: S3, val4: S4, val5: S5) => boolean;
    throttle?: (f: () => void) => () => void;
    onResolve?: (result: ReturnType) => void;
    onReject?: (err: Error) => void;
}): [
    Selector<ReturnType | DefaultValue>,
    Selector<boolean>,
    Selector<any | undefined>,
    Action<() => Promise<ReturnType>>
];
export declare function createAsyncSelector<S1, S2, S3, S4, S5, S6, ReturnType, DefaultValue = null>(params: {
    defaultValue: DefaultValue;
    inputs: [
        AtomOrSelector<S1>,
        AtomOrSelector<S2>,
        AtomOrSelector<S3>,
        AtomOrSelector<S4>,
        AtomOrSelector<S5>,
        AtomOrSelector<S6>
    ];
    func: (val1: S1, val2: S2, val3: S3, val4: S4, val5: S5, val6: S6, state: AsyncSelectorPromiseState<ReturnType>) => Promise<ReturnType>;
    id?: string;
    shouldUseAsync?: (val1: S1, val2: S2, val3: S3, val4: S4, val5: S5, val6: S6) => boolean;
    throttle?: (f: () => void) => () => void;
    onResolve?: (result: ReturnType) => void;
    onReject?: (err: Error) => void;
}): [
    Selector<ReturnType | DefaultValue>,
    Selector<boolean>,
    Selector<any | undefined>,
    Action<() => Promise<ReturnType>>
];
export declare function createAsyncSelector<S1, S2, S3, S4, S5, S6, S7, ReturnType, DefaultValue = null>(params: {
    defaultValue: DefaultValue;
    inputs: [
        AtomOrSelector<S1>,
        AtomOrSelector<S2>,
        AtomOrSelector<S3>,
        AtomOrSelector<S4>,
        AtomOrSelector<S5>,
        AtomOrSelector<S6>,
        AtomOrSelector<S7>
    ];
    func: (val1: S1, val2: S2, val3: S3, val4: S4, val5: S5, val6: S6, val7: S7, state: AsyncSelectorPromiseState<ReturnType>) => Promise<ReturnType>;
    id?: string;
    shouldUseAsync?: (val1: S1, val2: S2, val3: S3, val4: S4, val5: S5, val6: S6, val7: S7) => boolean;
    throttle?: (f: () => void) => () => void;
    onResolve?: (result: ReturnType) => void;
    onReject?: (err: Error) => void;
}): [
    Selector<ReturnType | DefaultValue>,
    Selector<boolean>,
    Selector<any | undefined>,
    Action<() => Promise<ReturnType>>
];
export declare function createAsyncSelector<S1, S2, S3, S4, S5, S6, S7, S8, ReturnType, DefaultValue = null>(params: {
    defaultValue: DefaultValue;
    inputs: [
        AtomOrSelector<S1>,
        AtomOrSelector<S2>,
        AtomOrSelector<S3>,
        AtomOrSelector<S4>,
        AtomOrSelector<S5>,
        AtomOrSelector<S6>,
        AtomOrSelector<S7>,
        AtomOrSelector<S8>
    ];
    func: (val1: S1, val2: S2, val3: S3, val4: S4, val5: S5, val6: S6, val7: S7, val8: S8, state: AsyncSelectorPromiseState<ReturnType>) => Promise<ReturnType>;
    id?: string;
    shouldUseAsync?: (val1: S1, val2: S2, val3: S3, val4: S4, val5: S5, val6: S6, val7: S7, val8: S8) => boolean;
    throttle?: (f: () => void) => () => void;
    onResolve?: (result: ReturnType) => void;
    onReject?: (err: Error) => void;
}): [
    Selector<ReturnType | DefaultValue>,
    Selector<boolean>,
    Selector<any | undefined>,
    Action<() => Promise<ReturnType>>
];
export declare function createAsyncSelector<S1, S2, S3, S4, S5, S6, S7, S8, S9, ReturnType, DefaultValue = null>(params: {
    defaultValue: DefaultValue;
    inputs: [
        AtomOrSelector<S1>,
        AtomOrSelector<S2>,
        AtomOrSelector<S3>,
        AtomOrSelector<S4>,
        AtomOrSelector<S5>,
        AtomOrSelector<S6>,
        AtomOrSelector<S7>,
        AtomOrSelector<S8>,
        AtomOrSelector<S9>
    ];
    func: (val1: S1, val2: S2, val3: S3, val4: S4, val5: S5, val6: S6, val7: S7, val8: S8, val9: S9, state: AsyncSelectorPromiseState<ReturnType>) => Promise<ReturnType>;
    id?: string;
    shouldUseAsync?: (val1: S1, val2: S2, val3: S3, val4: S4, val5: S5, val6: S6, val7: S7, val8: S8, val9: S9) => boolean;
    throttle?: (f: () => void) => () => void;
    onResolve?: (result: ReturnType) => void;
    onReject?: (err: Error) => void;
}): [
    Selector<ReturnType | DefaultValue>,
    Selector<boolean>,
    Selector<any | undefined>,
    Action<() => Promise<ReturnType>>
];
