export declare function mapValues(o: Object, f: Function): Object;
