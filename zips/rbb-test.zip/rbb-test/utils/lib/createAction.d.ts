import { Atom, AtomOrSelector, IStore } from 'redab-core';
import { Action, AnyFunction } from './types';
export declare function createAction<Use extends {
    [key: string]: AtomOrSelector<any> | Action<AnyFunction>;
}, Func extends (...p: any[]) => any>(params: {
    use: Use;
    func: (nodes: Use) => Func;
    id?: string;
    key?: any;
    store?: IStore;
    loggingMap?: Map<Atom<any>, any>;
}): Action<Func>;
