import { Atom } from 'redab-core';
export declare type AnyFunction = (...p: any[]) => any;
export declare type Action<T extends AnyFunction> = T & {
    construct: any;
};
export declare type Setter<Input> = (val: Input) => void;
export declare type AsyncSelectorPromiseState<T> = {
    callId: string;
    cancelled: boolean;
    onCancel: () => void;
    onReject: () => Error;
    onResolve: () => T;
    key: any;
};
export declare type AsyncActionState = {
    id: string;
    cancelled: boolean;
    onCancel: () => void;
};
export declare type Atomify<Object> = {
    [P in keyof Object]: Object[P] extends AnyFunction ? Atom<ReturnType<Object[P]>> : Atom<Object[P]>;
};
