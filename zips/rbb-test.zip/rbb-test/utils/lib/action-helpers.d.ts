import { Action } from '.';
import { AnyFunction } from './types';
export declare function transformDependencies(deps: object, key: any, loggingMap?: Map<any, any>, disallowNotifications?: boolean): any;
export declare function isAction(obj: any): boolean;
export declare function isEitherSelector(obj: any): boolean;
export declare function injectKey<Func extends AnyFunction>(action: Action<Func>, key: any): Action<Func>;
