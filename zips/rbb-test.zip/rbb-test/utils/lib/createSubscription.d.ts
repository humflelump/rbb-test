import { AtomOrSelector, Listener, Selector } from 'redab-core';
declare type SetterVal<T> = T | ((val: T) => T);
export declare function createSubscription<Return>(params: {
    id?: string;
    defaultValue: Return;
    inputs?: [];
    onSubscribe: (vals: [], setter: (f: SetterVal<Return>) => void) => {
        onUnsubscribe: (values: []) => void;
        onInputsChanged?: (current: [], prev: [] | null) => void;
        onSubscriptionsChanged?: (newListeners: Listener[], prevListeners: Listener[]) => void;
    };
}): Selector<Return>;
export declare function createSubscription<Return, R1>(params: {
    id?: string;
    defaultValue: Return;
    inputs: [AtomOrSelector<R1>];
    onSubscribe: (vals: [R1], setter: (f: SetterVal<Return>) => void) => {
        onUnsubscribe: (values: [R1]) => void;
        onInputsChanged?: (current: [R1], prev: [R1] | null) => void;
        onSubscriptionsChanged?: (newListeners: Listener[], prevListeners: Listener[]) => void;
    };
}): Selector<Return>;
export declare function createSubscription<Return, R1, R2>(params: {
    id?: string;
    defaultValue: Return;
    inputs: [AtomOrSelector<R1>, AtomOrSelector<R2>];
    onSubscribe: (vals: [R1, R2], setter: (f: SetterVal<Return>) => void) => {
        onUnsubscribe: (values: [R1, R2]) => void;
        onInputsChanged?: (current: [R1, R2], prev: [R1, R2] | null) => void;
        onSubscriptionsChanged?: (newListeners: Listener[], prevListeners: Listener[]) => void;
    };
}): Selector<Return>;
export declare function createSubscription<Return, R1, R2, R3>(params: {
    id?: string;
    defaultValue: Return;
    inputs: [AtomOrSelector<R1>, AtomOrSelector<R2>, AtomOrSelector<R3>];
    onSubscribe: (vals: [R1, R2, R3], setter: (f: SetterVal<Return>) => void) => {
        onUnsubscribe: (values: [R1, R2, R3]) => void;
        onInputsChanged?: (current: [R1, R2, R3], prev: [R1, R2, R3] | null) => void;
        onSubscriptionsChanged?: (newListeners: Listener[], prevListeners: Listener[]) => void;
    };
}): Selector<Return>;
export declare function createSubscription<Return, R1, R2, R3, R4>(params: {
    id?: string;
    defaultValue: Return;
    inputs: [
        AtomOrSelector<R1>,
        AtomOrSelector<R2>,
        AtomOrSelector<R3>,
        AtomOrSelector<R4>
    ];
    onSubscribe: (vals: [R1, R2, R3, R4], setter: (f: SetterVal<Return>) => void) => {
        onUnsubscribe: (values: [R1, R2, R3, R4]) => void;
        onInputsChanged?: (current: [R1, R2, R3, R4], prev: [R1, R2, R3, R4] | null) => void;
        onSubscriptionsChanged?: (newListeners: Listener[], prevListeners: Listener[]) => void;
    };
}): Selector<Return>;
export declare function createSubscription<Return, R1, R2, R3, R4, R5>(params: {
    id?: string;
    defaultValue: Return;
    inputs: [
        AtomOrSelector<R1>,
        AtomOrSelector<R2>,
        AtomOrSelector<R3>,
        AtomOrSelector<R4>,
        AtomOrSelector<R5>
    ];
    onSubscribe: (vals: [R1, R2, R3, R4, R5], setter: (f: SetterVal<Return>) => void) => {
        onUnsubscribe: (values: [R1, R2, R3, R4, R5]) => void;
        onInputsChanged?: (current: [R1, R2, R3, R4, R5], prev: [R1, R2, R3, R4, R5] | null) => void;
        onSubscriptionsChanged?: (newListeners: Listener[], prevListeners: Listener[]) => void;
    };
}): Selector<Return>;
export declare function createSubscription<Return, R1, R2, R3, R4, R5, R6>(params: {
    id?: string;
    defaultValue: Return;
    inputs: [
        AtomOrSelector<R1>,
        AtomOrSelector<R2>,
        AtomOrSelector<R3>,
        AtomOrSelector<R4>,
        AtomOrSelector<R5>,
        AtomOrSelector<R6>
    ];
    onSubscribe: (vals: [R1, R2, R3, R4, R5, R6], setter: (f: SetterVal<Return>) => void) => {
        onUnsubscribe: (values: [R1, R2, R3, R4, R5, R6]) => void;
        onInputsChanged?: (current: [R1, R2, R3, R4, R5, R6], prev: [R1, R2, R3, R4, R5, R6] | null) => void;
        onSubscriptionsChanged?: (newListeners: Listener[], prevListeners: Listener[]) => void;
    };
}): Selector<Return>;
export {};
