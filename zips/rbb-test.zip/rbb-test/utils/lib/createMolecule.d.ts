import { IStore } from 'redab-core';
import { Atomify } from './types';
export declare function createMolecule<Slice>(params: {
    slice: Slice;
    key: string;
    multi?: boolean;
    store?: IStore;
}): Atomify<Slice>;
