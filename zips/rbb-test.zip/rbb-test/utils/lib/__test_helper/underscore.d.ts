export declare const _: any;
