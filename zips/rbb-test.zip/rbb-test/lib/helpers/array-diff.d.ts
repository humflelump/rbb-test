export declare function arraysDiff(a1: null | any[], a2: null | any[]): boolean;
