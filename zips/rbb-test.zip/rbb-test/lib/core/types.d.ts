export declare type Listener<T = undefined> = {
    (): void;
    data?: T;
};
export declare type ListenerListener = (newListeners: Listener<any>[], prevListeners: Listener<any>[], key: any) => void;
export declare type AtomMiddleware<T> = (next: T, curr: T, atom: Atom<T>, key: any) => T;
export declare type ParentType = {
    getId: () => string;
    getListeners: (key?: any) => Listener<any>[];
    getDependencies: (key?: any) => AtomOrSelector<any>[];
    getDependants: (key?: any) => AtomOrSelector<any>[];
    subscribe: (l: Listener<any>, key?: any) => void;
    unsubscribe: (l: Listener<any>, key?: any) => void;
    listenersChanged: ListenerListener | null;
};
export declare type Atom<T, M = null> = {
    get: (key?: any) => T;
    update(func: (val: T) => T, key?: any): any;
    set: (val: T, key?: any) => void;
    getMetadata: () => M;
    setIfShouldNotifyListeners(bool: boolean, key?: any): void;
    shouldNotifyListeners(key?: any): boolean;
    addMiddleware(middleware: AtomMiddleware<T>): void;
    removeMiddleware(middleware: AtomMiddleware<T>): void;
} & ParentType;
export declare type Selector<T> = {
    get: (key?: any) => T;
} & ParentType;
export declare type DynamicSelector<T> = {
    get: (key?: any) => T;
} & ParentType;
export declare type AtomOrSelector<T, M = null> = Atom<T, M> | Selector<T> | DynamicSelector<T>;
