export declare const atomMethods: {
    get: (key: any) => any;
    update: (func: any, key: any) => void;
    set: (val: any, origKey: any) => void;
    getDependencies(): any[];
    setIfShouldNotifyListeners(bool: any, key: any): void;
    shouldNotifyListeners(key: any): any;
    getMetadata: () => any;
    addMiddleware: (f: any) => void;
    removeMiddleware: (f: any) => void;
};
