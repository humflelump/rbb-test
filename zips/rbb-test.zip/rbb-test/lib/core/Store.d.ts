import { Atom, AtomMiddleware } from './types';
export interface IStore {
    middleware: AtomMiddleware<any>[];
    atoms: {
        [key: string]: Atom<any>;
    };
    atomCreated(atom: Atom<any>): void;
    addMiddleware(...middleware: AtomMiddleware<any>[]): void;
    removeMiddleware(middleware: AtomMiddleware<any>): void;
    subscriptions: ((msg: unknown) => void)[];
    sendMessage(msg: any): void;
    subscribe(subscription: (msg: any) => void): void;
    unsubscribe(subscription: (msg: any) => void): void;
    getAllAtoms(): {
        [key: string]: Atom<any>;
    };
}
export declare class Store implements IStore {
    middleware: AtomMiddleware<any>[];
    atoms: {
        [key: string]: Atom<any>;
    };
    subscriptions: ((msg: unknown) => void)[];
    getAllAtoms(): {
        [key: string]: Atom<any, null>;
    };
    atomCreated(atom: Atom<any>): void;
    addMiddleware(...middleware: AtomMiddleware<any>[]): void;
    removeMiddleware(middleware: AtomMiddleware<any>): void;
    subscribe(subscription: (msg: any) => void): void;
    unsubscribe(subscription: (msg: any) => void): void;
    sendMessage(msg: any): void;
}
export declare const DEFAULT_STORE: Store;
