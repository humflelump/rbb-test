import { IStore } from '../core/Store';
import { Atom, AtomOrSelector, Selector } from '../core/types';
import { Action, AnyFunction } from './action-helpers';
import { AsyncActionState } from './types';
export declare function createAsyncAction<Use extends {
    [key: string]: AtomOrSelector<any> | Action<AnyFunction>;
}, Func extends (...p: any[]) => Promise<any>>(props: {
    id?: string;
    use: Use;
    func: (node: Use, status: AsyncActionState) => Func;
    duplicate?: boolean;
    key?: any;
    loggingMap?: Map<Atom<any>, any>;
    store?: IStore;
}): [Action<Func>, Selector<boolean>, Selector<Error | undefined>];
