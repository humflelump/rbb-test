import { AtomOrSelector, Selector } from "../core/types";
export declare function createThrottledSelector<ReturnType>(params: {
    id?: string;
    inputs?: [];
    func: () => ReturnType;
    throttle: (f: () => void) => () => void;
}): Selector<ReturnType>;
export declare function createThrottledSelector<S1, ReturnType>(params: {
    id?: string;
    inputs: [AtomOrSelector<S1>];
    func: (val1: S1) => ReturnType;
    throttle: (f: () => void) => () => void;
}): Selector<ReturnType>;
export declare function createThrottledSelector<S1, S2, ReturnType>(params: {
    id?: string;
    inputs: [AtomOrSelector<S1>, AtomOrSelector<S2>];
    func: (val1: S1, val2: S2) => ReturnType;
    throttle: (f: () => void) => () => void;
}): Selector<ReturnType>;
export declare function createThrottledSelector<S1, S2, S3, ReturnType>(params: {
    id?: string;
    inputs: [AtomOrSelector<S1>, AtomOrSelector<S2>, AtomOrSelector<S3>];
    func: (val1: S1, val2: S2, val3: S3) => ReturnType;
    throttle: (f: () => void) => () => void;
}): Selector<ReturnType>;
export declare function createThrottledSelector<S1, S2, S3, S4, ReturnType>(params: {
    id?: string;
    inputs: [
        AtomOrSelector<S1>,
        AtomOrSelector<S2>,
        AtomOrSelector<S3>,
        AtomOrSelector<S4>
    ];
    func: (val1: S1, val2: S2, val3: S3, val4: S4) => ReturnType;
    throttle: (f: () => void) => () => void;
}): Selector<ReturnType>;
export declare function createThrottledSelector<S1, S2, S3, S4, S5, ReturnType>(params: {
    id?: string;
    inputs: [
        AtomOrSelector<S1>,
        AtomOrSelector<S2>,
        AtomOrSelector<S3>,
        AtomOrSelector<S4>,
        AtomOrSelector<S5>
    ];
    func: (val1: S1, val2: S2, val3: S3, val4: S4, val5: S5) => ReturnType;
    throttle: (f: () => void) => () => void;
}): Selector<ReturnType>;
export declare function createThrottledSelector<S1, S2, S3, S4, S5, S6, ReturnType>(params: {
    id?: string;
    inputs: [
        AtomOrSelector<S1>,
        AtomOrSelector<S2>,
        AtomOrSelector<S3>,
        AtomOrSelector<S4>,
        AtomOrSelector<S5>,
        AtomOrSelector<S6>
    ];
    func: (val1: S1, val2: S2, val3: S3, val4: S4, val5: S5, val6: S6) => ReturnType;
    throttle: (f: () => void) => () => void;
}): Selector<ReturnType>;
export declare function createThrottledSelector<S1, S2, S3, S4, S5, S6, S7, ReturnType>(params: {
    id?: string;
    inputs: [
        AtomOrSelector<S1>,
        AtomOrSelector<S2>,
        AtomOrSelector<S3>,
        AtomOrSelector<S4>,
        AtomOrSelector<S5>,
        AtomOrSelector<S6>,
        AtomOrSelector<S7>
    ];
    func: (val1: S1, val2: S2, val3: S3, val4: S4, val5: S5, val6: S6, val7: S7) => ReturnType;
    throttle: (f: () => void) => () => void;
}): Selector<ReturnType>;
export declare function createThrottledSelector<S1, S2, S3, S4, S5, S6, S7, S8, ReturnType>(params: {
    id?: string;
    inputs: [
        AtomOrSelector<S1>,
        AtomOrSelector<S2>,
        AtomOrSelector<S3>,
        AtomOrSelector<S4>,
        AtomOrSelector<S5>,
        AtomOrSelector<S6>,
        AtomOrSelector<S7>,
        AtomOrSelector<S8>
    ];
    func: (val1: S1, val2: S2, val3: S3, val4: S4, val5: S5, val6: S6, val7: S7, val8: S8) => ReturnType;
    throttle: (f: () => void) => () => void;
}): Selector<ReturnType>;
export declare function createThrottledSelector<S1, S2, S3, S4, S5, S6, S7, S8, S9, ReturnType>(params: {
    id?: string;
    inputs: [
        AtomOrSelector<S1>,
        AtomOrSelector<S2>,
        AtomOrSelector<S3>,
        AtomOrSelector<S4>,
        AtomOrSelector<S5>,
        AtomOrSelector<S6>,
        AtomOrSelector<S7>,
        AtomOrSelector<S8>,
        AtomOrSelector<S9>
    ];
    func: (val1: S1, val2: S2, val3: S3, val4: S4, val5: S5, val6: S6, val7: S7, val8: S8, val9: S9) => ReturnType;
    throttle: (f: () => void) => () => void;
}): Selector<ReturnType>;
