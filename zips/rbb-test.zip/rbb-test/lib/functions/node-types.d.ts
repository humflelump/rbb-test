export declare function isAtom(obj: any): boolean;
export declare function isSelector(obj: any): boolean;
export declare function isDynamicSelector(obj: any): boolean;
export declare function isEitherSelector(obj: any): boolean;
export declare function isAction(obj: any): boolean;
