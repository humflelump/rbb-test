import { IStore } from '../core/Store';
import { Atomify } from './types';
export declare function createMolecule<Slice>(params: {
    slice: Slice;
    key: string;
    duplicate?: boolean;
    store?: IStore;
}): Atomify<Slice>;
