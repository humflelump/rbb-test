export declare type AnyFunction = (...p: any[]) => any;
export declare type Action<T extends AnyFunction> = T & {
    construct: any;
};
export declare function transformDependencies(deps: object, key: any, loggingMap?: Map<any, any>, disallowNotifications?: boolean): any;
