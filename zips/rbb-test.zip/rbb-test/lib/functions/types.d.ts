import { Atom } from '../core/types';
export declare type ActionFunction = {
    (): void;
    getId(): string;
};
export declare type Setter<Input> = (val: Input) => void;
export declare type AsyncSelectorPromiseState<T> = {
    callId: string;
    cancelled: boolean;
    onCancel: () => void;
    onReject: () => Error;
    onResolve: () => T;
    key: any;
};
export declare type AsyncActionState = {
    id: string;
    cancelled: boolean;
    onCancel: () => void;
};
export declare type AsyncActionFunction = {
    (): AsyncActionState;
    getId(): string;
};
declare type AnyFunction = (...p: any[]) => any;
export declare type Atomify<Object> = {
    [P in keyof Object]: Object[P] extends AnyFunction ? Atom<ReturnType<Object[P]>> : Atom<Object[P]>;
};
export declare type ActionChange = {
    from: any;
    to: any;
    atom: Atom<any, any>;
};
export declare type ActionEffect = {
    id: string;
    changes: ActionChange[];
};
export {};
