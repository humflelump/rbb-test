import { IStore } from '../core/Store';
import { Atom, AtomOrSelector } from '../core/types';
import { Action, AnyFunction } from './action-helpers';
export declare function createAction<Use extends {
    [key: string]: AtomOrSelector<any> | Action<AnyFunction>;
}, Func extends (...p: any[]) => any>(params: {
    use: Use;
    func: (nodes: Use) => Func;
    id?: string;
    key?: any;
    store?: IStore;
    loggingMap?: Map<Atom<any>, any>;
}): Action<Func>;
export declare function injectKey<Func extends AnyFunction>(action: Action<Func>, key: any): Action<Func>;
