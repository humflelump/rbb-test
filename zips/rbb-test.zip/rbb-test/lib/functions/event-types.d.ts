import { Atom } from '../core/types';
export declare type ACTION_COMPLETED = {
    type: 'ACTION_COMPLETED';
    id: string;
    arguments: any[];
    returnVal: any;
    updates: {
        atom: Atom<any>;
        value: any;
    };
};
export declare type ASYNC_ACTION_STARTED = {
    type: 'ASYNC_ACTION_STARTED';
    id: string;
    arguments: any[];
    callId: string;
};
export declare type ASYNC_ACTION_ENDED = {
    type: 'ASYNC_ACTION_ENDED';
    id: string;
    callId: string;
    cancelled: boolean;
    hasError: boolean;
    returnVal: any;
    updates: {
        atom: Atom<any>;
        value: any;
    };
};
