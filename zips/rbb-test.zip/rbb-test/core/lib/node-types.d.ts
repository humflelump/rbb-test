export declare function isAtom(obj: any): boolean;
export declare function isSelector(obj: any): boolean;
export declare function isDynamicSelector(obj: any): boolean;
