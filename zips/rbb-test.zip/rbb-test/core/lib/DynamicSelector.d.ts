import { AtomOrSelector, DynamicSelector, ListenerListener } from './types';
export declare const DYNAMIC_SELECTOR_PROTOTYPE: {
    get: (key: any) => any;
    revokeCache: (visits: any, key: any) => void;
    revokeHelper(visits: any, key: any): void;
    disconnect(parent: any, key: any): void;
    connect(parent: any, key: any): void;
    notDupe(): boolean;
    subscribe_(listener: any, visits: any, key: any): void;
    subscribe(listener: any, key: any): void;
    unsubscribe_(listener: any, visits: any, key: any): void;
    unsubscribe(listener: any, key: any): void;
    getId(): any;
    getListeners(key: any): unknown[];
    getDependencies(key: any): any[];
    getDependants(key: any): any[];
    garbageCollect(key: any): void;
    visit(key: any): void;
    getMetadata(): any;
};
export declare function dynamicSelector<Return>(params: {
    id?: string;
    inputs?: AtomOrSelector<Return>;
    func: (get: <T>(node: AtomOrSelector<T>) => T) => Return;
    listenersChanged?: ListenerListener;
    metadata?: any;
}): DynamicSelector<Return>;
export declare function dynamicSelector<Return>(func: (get: <T>(node: AtomOrSelector<T>) => T) => Return): DynamicSelector<Return>;
