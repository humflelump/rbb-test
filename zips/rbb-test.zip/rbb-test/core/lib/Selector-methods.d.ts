export declare const selectorMethods: {
    get: (key: any) => any;
};
