export declare const dynamicSelectorMethods: {
    get: (key: any) => any;
    revokeCache: (visits: any, key: any) => void;
};
