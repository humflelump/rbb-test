export declare const parentMethods: {
    revokeHelper(visits: any, key: any): void;
    revokeCache(visits: any, key: any): void;
    disconnect(parent: any, key: any): void;
    connect(parent: any, key: any): void;
    notDupe(): boolean;
    subscribe_(listener: any, visits: any, key: any): void;
    subscribe(listener: any, key: any): void;
    unsubscribe_(listener: any, visits: any, key: any): void;
    unsubscribe(listener: any, key: any): void;
    getId(): any;
    getListeners(key: any): unknown[];
    getDependencies(key: any): any[];
    getDependants(key: any): any[];
    garbageCollect(key: any): void;
    visit(key: any): void;
    getMetadata(): any;
};
